import Pyro.core
import Pyro.naming

uri = raw_input("URI ")
obj = Pyro.core.getProxyForURI(uri)

print obj.add(12, 3, 12)
