import Pyro4

class addClass:
	def add(self, a ,b):
		self.cont +=1
		print ("ADDDDDD", a, b, self.cont)
		return a+b
	def __init__(self):
		self.cont = 0
	
addRemote = Pyro4.expose(addClass)	


obj = addRemote()

obj2 = addRemote()

#Pyro4.core.initServer()
daemon = Pyro4.core.Daemon(host="194.210.228.209")



uri=daemon.register(obj,"addServer")
print (uri)
uri=daemon.register(obj2,"addServer2")
print (uri)
daemon.requestLoop()


