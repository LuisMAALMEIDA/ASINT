import Pyro4

uri = input("URI ")
obj = Pyro4.Proxy(uri)

print (obj.add(12, 3))
