import Pyro.core
import Pyro.naming

class addClass:
	def add(self, a ,b):
		self.cont +=1
		print a, b, self.cont
		return a+b
	def __init__(self):
		self.cont = 0
			
class addRemote(Pyro.core.ObjBase, addClass):
	def __init__(self):
		Pyro.core.ObjBase.__init__(self)
		addClass.__init__(self)


Pyro.core.initServer()
daemon = Pyro.core.Daemon()


locator = Pyro.naming.NameServerLocator()
ns = locator.getNS()
daemon.useNameServer(ns)



obj = addRemote()
obj2 = addRemote()

uri=daemon.connect(obj,"addServer")
uri=daemon.connect(obj2,"addServer2")
print uri
daemon.requestLoop()


print obj.add(12, 3)
