import Pyro.core
import Pyro.naming

#uri = raw_input("URI ")
locator = Pyro.naming.NameServerLocator()
ns = locator.getNS()
uri=ns.resolve('addServer')
print uri
obj = Pyro.core.getProxyForURI(uri)

print obj.add(12, 3)

uri2=ns.resolve('addServer2')
print uri2
obj2 = Pyro.core.getProxyForURI(uri2)
print obj2.add(12, 3)
