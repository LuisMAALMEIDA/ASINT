class teste:
  def x(self):
    print ("ola mundo")
