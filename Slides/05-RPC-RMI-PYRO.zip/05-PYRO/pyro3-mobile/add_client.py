import Pyro.core
import teste

t = teste.teste()

uri = raw_input("URI ")
obj = Pyro.core.getProxyForURI(uri)

print (obj.add(12, 3))
obj.xpto(t)
