import Pyro.core

class addClass:
	def add(self, a ,b):
		self.cont +=1
		print ("ADDDDDD", a, b, self.cont)
		return a+b
	def xpto(self, a):
		print (a)
		a.x()
	def __init__(self):
		self.cont = 0

class addRemote(Pyro.core.ObjBase, addClass):
        def __init__(self):
                Pyro.core.ObjBase.__init__(self)
                addClass.__init__(self)




obj = addRemote()

obj2 = addRemote()

#Pyro4.core.initServer()
Pyro.core.initServer()
daemon = Pyro.core.Daemon()



uri=daemon.connect(obj,"addServer")
print uri
uri=daemon.connect(obj2,"addServer")
print uri
daemon.requestLoop()
