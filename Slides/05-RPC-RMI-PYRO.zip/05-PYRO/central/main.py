import add_class

obj = add_class.addClass()

print obj.add(12, 3)
