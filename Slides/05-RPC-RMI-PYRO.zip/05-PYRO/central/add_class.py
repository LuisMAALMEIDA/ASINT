
class addClass:
	def add(self, a ,b):
		print a, b
		return a+b
	def sleep(self):
		for i in range(1000):
			print i
			
