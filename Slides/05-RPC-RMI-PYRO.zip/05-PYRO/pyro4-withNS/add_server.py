import Pyro4

class addClass:
	def add(self, a ,b):
		self.cont +=1
		print ("ADDDDDD", a, b, self.cont)
		return a+b
	def __init__(self):
		self.cont = 0

addRemote = Pyro4.expose(addClass)


obj = addRemote()

obj2 = addRemote()

#Pyro4.core.initServer()
ns=Pyro4.locateNS()
daemon = Pyro4.core.Daemon()


uri=daemon.register(obj,"addServer")
ns.register("addServer", uri)
print (uri)
uri=daemon.register(obj2,"addServer2")
ns.register("addServer2", uri)
print (uri)


daemon.requestLoop()
