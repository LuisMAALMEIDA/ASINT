import Pyro4

nameserver=Pyro4.locateNS()

objName = raw_input("object name")
uri=nameserver.lookup(objName)

print uri

obj = Pyro4.Proxy(uri)

print (obj.add(12, 3))
