import java.rmi.RMISecurityManager;
import java.rmi.Naming;
import java.rmi.RemoteException;

public class HelloClient
{
    public static void main(String arg[])
    {
        String message = "blank";

        

        try
        {
           Hello obj = (Hello) Naming.lookup( "//" +
                "127.0.0.1" +
                "/HelloServer");         //objectname in registry
           System.out.println(obj.sayHello("xxx"));
        }
        catch (Exception e)
        {
           System.out.println("HelloClient exception: " + e.getMessage());
           e.printStackTrace();
        }
    }
}
