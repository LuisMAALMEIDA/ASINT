import java.rmi.*;

public interface Hello extends Remote
{
        String sayHello(String arg) throws RemoteException;
}
