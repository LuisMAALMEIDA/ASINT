export PYRO_SERIALIZERS_ACCEPTED=serpent,json,marshal,pickle
pyro4-ns
